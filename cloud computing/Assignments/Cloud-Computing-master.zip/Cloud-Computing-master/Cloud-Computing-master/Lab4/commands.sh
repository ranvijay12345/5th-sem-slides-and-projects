aws s3 cp s3://bucket191998/About.html /var/www/html/
aws s3 cp s3://bucket191998/Error.html /var/www/html/
aws s3 cp s3://bucket191998/homepage.html /var/www/html/
aws s3 cp s3://bucket191998/kinds.html /var/www/html/
aws s3 cp s3://bucket191998/Types.html /var/www/html/
